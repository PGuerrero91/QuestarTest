# Processes to force close
$processesToClose = @("msedge", "Teams", "chrome")

foreach ($processName in $processesToClose) {
    # Get all processes for the specified name
    $processes = Get-Process -Name $processName -ErrorAction SilentlyContinue

    # Check if processes are running
    if ($processes) {
        # Forcefully terminate processes
        Stop-Process -Name $processName -Force
    }
}

# Open Questar after processes are terminated
Start-Process "C:\Program Files (x86)\Questar Assessment Inc\QuestarStudent-NY\QuestarStudent-NY.exe"




